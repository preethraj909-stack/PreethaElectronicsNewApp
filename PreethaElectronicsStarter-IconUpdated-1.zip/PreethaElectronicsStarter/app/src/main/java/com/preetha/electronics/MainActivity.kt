package com.preetha.electronics

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val navy = Color.rgb(16, 27, 51)
    private val orange = Color.rgb(242, 140, 40)
    private val white = Color.WHITE
    private val muted = Color.rgb(190, 199, 214)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        val scroll = ScrollView(this).apply { setBackgroundColor(navy) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(24))
        }
        scroll.addView(root)
        root.addView(text("PREETHA ELECTRONICS", 24, white, true))
        root.addView(text("Billing & Service Management", 15, muted, false).apply { setPadding(0, dp(5), 0, dp(2)) })
        root.addView(text("Since 1980  •  Punalur  •  Service All Over 25 Km", 12, muted, false).apply { setPadding(0, dp(5), 0, dp(20)) })
        root.addView(section("QUICK ACCESS"))
        val actions = listOf("🧾   Invoice", "📄   Quotation", "👥   Customers", "🛠   Service Jobs", "📦   Items / Stock", "📊   Reports")
        actions.forEach { root.addView(card(it, "Tap to open (feature coming later)")) }
        root.addView(section("TODAY'S OVERVIEW"))
        val stats = listOf("Today's Sales" to "₹0", "Service Jobs" to "0", "Total Customers" to "0", "Stock Items" to "0")
        stats.forEach { (label, value) -> root.addView(card(label, value, true)) }
        root.addView(text("Home     Invoice     Quote     Customers     Service     Items     Reports", 12, muted, false).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(24), 0, dp(8))
        })
        setContentView(scroll)
    }
    private fun section(s: String) = text(s, 12, orange, true).apply { setPadding(0, dp(20), 0, dp(10)) }
    private fun card(title: String, subtitle: String, stat: Boolean = false): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            setBackgroundColor(Color.rgb(29, 43, 70))
        }
        box.addView(text(title, if (stat) 14 else 16, white, true))
        box.addView(text(subtitle, if (stat) 22 else 12, if (stat) orange else muted, !stat).apply { setPadding(0, dp(6), 0, 0) })
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        params.bottomMargin = dp(10)
        box.layoutParams = params
        return box
    }
    private fun text(value: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
